<?php
//This script will handle login
session_start();

// check if the user is already logged in
if(isset($_SESSION['username']))
{
    header("location: index.php");
    exit;
}
require_once "connection.php";

$username = $password = "";
$err = "";

// if request method is post
if ($_SERVER['REQUEST_METHOD'] == "POST"){
    if(empty(trim($_POST['username'])) || empty(trim($_POST['password'])))
    {
        $err = "Please enter username + password";
    }
    else{
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
    }


if(empty($err))
{
    $sql = "SELECT id, username, password FROM register WHERE username = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $param_username);
    $param_username = $username;
    
    
    // Try to execute this statement
    if(mysqli_stmt_execute($stmt)){
        mysqli_stmt_store_result($stmt);
        if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt))
                    {
                        if(password_verify($password, $hashed_password))
                        {
                            // this means the password is corrct. Allow user to login
                            session_start();
                            $_SESSION["username"] = $username;
                            $_SESSION["id"] = $id;
                            $_SESSION["loggedin"] = true;

                            //Redirect user to welcome page
                            header("location: index.php");
                            
                        }
                    }

                }

    }
}    


}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Buddies</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Bootsrap CSS -->
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Register css file link -->
    <link rel="stylesheet" href="css/Register.css">

</head>
<body>
    
<?php require 'Partials/_nav.php' ?>
   
<!-- Registration Form starts -->

<div class="text-center mt-5 pt-5">
<h1>Login <span>Form</span></h1>
</div>

<div id="message"></div>
<form id="form" action="Register.php" method="post" style="width: 100% ; margin-left: 25%; margin-bottom: 5%;">
<div class="form my-5">
    <label for="exampleInputUsername" class="form-label fa-2x ">Username:</label>
    <br>
    <input type="text" class="form-control" id="login-Username" name="name">
    
</div>
<div class="formfields my-5">
  <label for="exampleInputPassword1" class="form-label fa-2x">Password:</label>
  <br>
  <input type="password" class="form-control w-50" id="login-pass" name="password">
</div>

  <button type="submit" class="btn btn-danger my-5" class="rounded-pill" >Submit</button>
  <button type="submit" class="btn btn-danger my-5" class="rounded-pill" ><a href="/Register.php" style="text-decoration: none; color: white;">Register</a></button>
</form>

<!-- footer section starts  -->

<?php require 'Partials/_footer.php'?>
<!-- footer section ends -->






















<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link -->
<script src="js/script.js"></script>
<script src="js/Register.js"></script>

</body>
</html>