let form = document.getElementById("form");
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      let Username = document.getElementById("Username");
      let pass = document.getElementById("pass");
      let email = document.getElementById("email");
      let message = document.getElementById('message');
      if(pass.value == "" || email.value == "" || Username.value == ""){
        message.innerHTML = `<div class="alert alert-warning alert-dismissible fade show" role="alert">
              <strong>Error</strong> Password/email/Username cannot be left blank.
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>`;
        setTimeout(() => {
        message.innerHTML = "";
         }, 3000);
      }
      else{
        message.innerHTML = `<div class="alert alert-success alert-dismissible fade show" role="alert">
              <strong>Success!</strong> Submitted
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>`;
        setTimeout(() => {
        message.innerHTML = "";
         }, 3000);
      }
    })