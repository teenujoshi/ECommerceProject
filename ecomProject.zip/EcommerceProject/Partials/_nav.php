<!-- header section starts  -->

<header class="header">

    <a href="/index.html" class="logo"><img src="image/Logo1.png" class="logo mt-2" alt="" srcset=""></a>

    <nav class="navbar">
        <a href="/index.html">home</a>
        <a href="#products">products</a>
        <a href="#featured">featured</a>
        <a href="EcommerceProject/Register.php">Register</a>
        <a href="/login.php">Login</a>
        <a href="#review">Review</a>
        <a href="#contact">contact</a>
        <a href="#blogs">blogs</a>
    </nav>

    <div class="icons">
        <div id="menu-btn" class="fas fa-bars"></div>
        <div id="search-btn" class="fas fa-search"></div>
        <a href="/cart.html" class="fas fa-shopping-cart"></a>
    </div>

    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>

</header>

<!-- header section ends -->
