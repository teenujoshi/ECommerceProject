<?php


    $conn = mysqli_connect("localhost", "root", "", "rentbuddies")
            or die("couldn't connect to the database");



?>