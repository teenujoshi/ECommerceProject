<!-- INSERT INTO `register` (`id`, `username`, `email`, `phoneno`, `houseno`, `street`, `state`, `city`, `pincode`, `password`, `confirm_password`) VALUES ('1', 'Prabh', 'example@gmail.com', '7042271258', '43', '2nd Floor Masjid Lane Jangpura Bhogal', 'Delhi', 'New Delhi', '110014', 'Password', 'Password'); -->


<?php
require_once "connection.php";

$username = $email = $phoneno = $houseno = $street = $state = $city = $pincode = $password = $confirm_password = "";
$username_err = $email_err = $phoneno_err = $houseno_err = $street_err = $state_err = $city_err = $pincode_err = $password_err = $confirm_password_err = "";

if ($_SERVER['REQUEST_METHOD'] == "POST"){

    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Username cannot be blank";
    }
    else{
        $sql = "SELECT id FROM users WHERE username = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt)
        {
            mysqli_stmt_bind_param($stmt, "s", $param_username);

            // Set the value of param username
            $param_username = trim($_POST['username']);

            // Try to execute this statement
            if(mysqli_stmt_execute($stmt)){
                mysqli_stmt_store_result($stmt);
                if(mysqli_stmt_num_rows($stmt) == 1)
                {
                    $username_err = "This username is already taken"; 
                }
                else{
                    $username = trim($_POST['username']);
                }
            }
            else{
                echo "Something went wrong";
            }
        }
    }

    mysqli_stmt_close($stmt);


// Check for email
if(empty(trim($_POST['email']))){
    $email_err = "Email cannot be blank";
} 

else{
    $email = trim($_POST['email']);
}

// Check for phoneno
if(empty(trim($_POST['phoneno']))){
    $phoneno_err = "Phone No. cannot be blank";
} 

else{
    $phoneno = trim($_POST['phoneno']);
}

// Check for houseno
if(empty(trim($_POST['houseno']))){
    $houseno_err = "House No. cannot be blank";
} 

else{
    $houseno = trim($_POST['houseno']);
}

// Check for street
if(empty(trim($_POST['street']))){
    $street_err = "street address cannot be blank";
} 

else{
    $street = trim($_POST['street']);
}

// Check for state
if(empty(trim($_POST['state']))){
    $state_err = "state address cannot be blank";
} 

else{
    $state = trim($_POST['state']);
}

// Check for city
if(empty(trim($_POST['city']))){
    $city_err = "city address cannot be blank";
} 

else{
    $city = trim($_POST['city']);
}

// Check for pincode
if(empty(trim($_POST['pincode']))){
    $pincode_err = "pincode cannot be blank";
} 

else{
    $pincode = trim($_POST['pincode']);
}

// Check for password
if(empty(trim($_POST['password']))){
    $password_err = "Password cannot be blank";
}
elseif(strlen(trim($_POST['password'])) < 5){
    $password_err = "Password cannot be less than 5 characters";
}
else{
    $password = trim($_POST['password']);
}

// Check for confirm password field
if(trim($_POST['password']) !=  trim($_POST['confirm_password'])){
    $password_err = "Passwords should match";
}

// If there were no errors, go ahead and insert into the database
if(empty($username_err) && empty($password_err) && empty($confirm_password_err))
{
    $sql = "INSERT INTO register (username, email, phoneno, houseno, street, state, city, pincode, password, confirm_password) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt)
    {
        mysqli_stmt_bind_param($stmt, "ss", $param_username, $email, $phoneno, $houseno, $street, $state, $city, $pincode, $param_password, $confirm_password);

        // Set these parameters
        $param_username = $username;
        $param_password = password_hash($password, PASSWORD_DEFAULT);

        // Try to execute the query
        if (mysqli_stmt_execute($stmt))
        {
            header("location: login.php");
        }
        else{
            echo "Something went wrong... cannot redirect!";
        }
    }
    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Buddies</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Bootsrap CSS -->
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <!-- Register css file link -->
    <link rel="stylesheet" href="css/Register.css">

</head>
<body>
    
<?php require 'Partials/_nav.php' ?>
 

<!-- Registration Form starts -->

<div class="text-center mt-5 pt-5">
<h1>Registration <span>Form</span></h1>
</div>

<div id="message"></div>
<form id="form" action="/Register.php" method="post" style="width: 100% ; margin-left: 25%; margin-bottom: 5%;">
<div class="form my-5">
    <label for="exampleInputUsername" class="form-label fa-2x ">Username:</label>
    <br>
    <input type="text" class="form-control" id="Username" name="name">
    
</div>
<div class="formfields my-5">
  <label for="exampleInputEmail1" class="form-label fa-2x">Email address:</label>
  <br>
  <input type="email" class="form-control w-50" id="email" name="email" aria-describedby="emailHelp">
  <div id="emailHelp" class="form-text"></div>
</div>
<div class="formfields my-5">
    <label for="exampleInputPassword1" class="form-label fa-2x">Phone Number:</label>
    <br>
    <input type="number" class="form-control w-50" id="phoneno" name="phoneno">
</div>
<div class="formfields my-5">
    <label for="exampleInputPassword1" class="form-label fa-2x">House/Flat No.:</label>
    <br>
    <input type="text" class="form-control w-50" id="houseno" name="houseno">
</div>
<div class="formfields my-5">
    <label for="exampleInputPassword1" class="form-label fa-2x">Street:</label>
    <br>
    <input type="text" class="form-control w-50" id="street" name="street">
</div>
<div class="formfields my-5">
    <label for="exampleInputPassword1" class="form-label fa-2x">State:</label>
    <br>
    <input type="text" class="form-control w-50" id="state" name="state">
</div>
<div class="formfields my-5">
    <label for="exampleInputPassword1" class="form-label fa-2x">City:</label>
    <br>
    <input type="text" class="form-control w-50" id="city" name="city">
</div>
<div class="formfields my-5">
  <label for="exampleInputPassword1" class="form-label fa-2x">Password:</label>
  <br>
  <input type="password" class="form-control w-50" id="pass" name="password">
</div>
<div class="formfields my-5">
    <label for="exampleInputPassword1" class="form-label fa-2x">Confirm Password:</label>
    <br>
    <input type="password" class="form-control w-50" id="pass" name="confirm_password">
  </div>
  <button type="submit" class="btn btn-danger my-5" class="rounded-pill" >Submit</button>
  <button type="reset" id="Register-btn" class="btn btn-danger my-5" class="rounded-pill" >Reset </button>
</form>

<!-- Registration Form ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>about us</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, nesciunt!</p>
        </div>

        <div class="box">
            <h3>category</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> Gadgets </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Furniture </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Colthings and Costumes </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> accesories </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> others </a>
        </div>

        <div class="box">
            <h3>quick links</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> home </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> products </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> featured </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> review </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> contact </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> blogs </a>
        </div>

        <div class="box">
            <h3>extra links</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> my order </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> my account </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> my listing </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> sell now </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> new offers </a>
        </div>

    </div>

    <div class="share">
        <a href="#" class="fab fa-facebook-f"></a>
        <a href="#" class="fab fa-linkedin"></a>
        <a href="#" class="fab fa-instagram"></a>
    </div>

    <div class="credit"> &copy; copyright @ 2021 by <span>Prabh Singh and Teenu Joshi</span> </div>
    
</section>

<!-- footer section ends -->






















<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link -->
<script src="js/script.js"></script>
<script src="js/Register.js"></script>


</body>
</html>