<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rent Buddies</title>

    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Bootsrap CSS -->
    <link rel="stylesheet" href="Bootstrap/css/bootstrap.min.css">

    <!-- custom css file link  -->
    <link rel="stylesheet" href="css/style.css">

    <!-- sproduct css file link -->
    <link rel="stylesheet" href="css/sproduct.css">

</head>

<body>
    <!-- header section starts  -->

<header class="header">

    <a href="/index.html" class="logo"><img src="image/Logo1.png" class="logo mt-2" alt="" srcset=""></a>

    <nav class="navbar">
        <a href="/index.html">home</a>
        <a href="#products">products</a>
        <a href="#featured">featured</a>
        <a href="/Register.php">Register</a>
        <a href="/login.php">Login</a>
        <a href="#contact">contact</a>
        <a href="#blogs">blogs</a>
    </nav>

    <div class="icons">
        <div id="menu-btn" class="fas fa-bars"></div>
        <div id="search-btn" class="fas fa-search"></div>
        <a href="/cart.html" class="fas fa-shopping-cart"></a>
        <a href="#" class="fas fa-heart"></a>
    </div>

    <form action="" class="search-form">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>

</header>

<!-- header section ends -->

<!-- product detail section starts -->

<div class = "main-wrapper">
    <div class = "container mt-5 pt-5">
        <div class = "product-div">
            <div class = "product-div-left">
                <div class = "img-container">
                    <img src = "image/Laptopsproduct.jpg" alt = "">
                </div>
                <div class = "hover-container">
                    <div><img src = "image/Laptopsproduct.jpg"></div>
                    <div><img src = "image/Laptopsproduct2"></div>
                    <div><img src = "image/Laptopsproduct3"></div>
                    <div><img src = "image/Laptopsproduct4.jpg"></div>
                    <div><img src = "image/Laptopsproduct5.png"></div>
                </div>
            </div>
            <div class = "product-div-right">
                <span class = "product-name">Product Name</span>
                <span class = "product-price">2500Rs/Day</span>
                <div class = "product-rating">
                    <span><i class = "fas fa-star check"></i></span>
                    <span><i class = "fas fa-star check"></i></span>
                    <span><i class = "fas fa-star check"></i></span>
                    <span><i class = "fas fa-star check"></i></span>
                    <span><i class = "fas fa-star-half-alt check"></i></span>
                    <span>(350 ratings)</span>
                </div>
                <p class = "product-description">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Vitae animi ad minima veritatis dolore. Architecto facere dignissimos voluptate fugit ratione molestias quis quidem exercitationem voluptas.</p>
                <div class = "btn-groups">
                    <button type = "button" class = "add-cart-btn"><i class = "fas fa-shopping-cart"></i>add to cart</button>
                    <button type = "button" class = "buy-now-btn"><i class = "fas fa-wallet"></i>rent now</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- product detail section ends -->

<!-- footer section starts  -->

<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>about us</h3>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum, nesciunt!</p>
        </div>

        <div class="box">
            <h3>category</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> Gadgets </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Furniture </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Colthings and Costumes </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> accesories </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> others </a>
        </div>

        <div class="box">
            <h3>quick links</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> home </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> products </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> featured </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> review </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> contact </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> blogs </a>
        </div>

        <div class="box">
            <h3>extra links</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> my order </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> my account </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> my listing </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> sell now </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> new offers </a>
        </div>

    </div>

    <div class="share">
        <a href="#" class="fab fa-facebook-f"></a>
        <a href="#" class="fab fa-linkedin"></a>
        <a href="#" class="fab fa-instagram"></a>
    </div>

    <div class="credit"> &copy; copyright @ 2021 by <span>Prabh Singh and Teenu Joshi</span> </div>
    
</section>

<!-- footer section ends -->


    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

    <!-- custom js file link -->
    <script src="js/script.js"></script>
    <script src="js/sproduct.js"></script>

    <!-- Bootstrap JS -->
    <script src="Bootstrap/js/bootstrap.bundle.js"></script>
</body>